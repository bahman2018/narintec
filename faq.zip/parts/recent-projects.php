
<!-- =========================================================================================== -->
<!-- =========================== Recent Projects =============================================== -->
<!-- =========================================================================================== -->

<!-- Projects Row -->
<div class="row">
  <div class="col-md-4">

    <div class="qt-portfolio-item">
      <a href="portfolio-single-item-1.php">
        <img class="img-responsive qt-fade" src="resources/img/portfolio/4.jpg" alt="">
      </a>
      <h3><a href="#">Project Four</a></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>

      <div class="row">
        <div class="col-md-6">
          <a class="btn btn-info btn-block" href="portfolio-single-item-1.php"><i class="fa fa-info-circle"></i> Details</a>
        </div>
        <div class="col-md-6">
          <a class="btn btn-primary btn-block" href="#"><i class="fa fa-eye"></i> Launch</a>
        </div>
      </div>

    </div>

  </div>
  <div class="col-md-4">

    <div class="qt-portfolio-item">
      <a href="portfolio-single-item-1.php">
        <img class="img-responsive qt-fade" src="resources/img/portfolio/5.jpg" alt="">
      </a>
      <h3><a href="#">Project Five</a></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>

      <div class="row">
        <div class="col-md-6">
          <a class="btn btn-info btn-block" href="portfolio-single-item-1.php"><i class="fa fa-info-circle"></i> Details</a>
        </div>
        <div class="col-md-6">
          <a class="btn btn-primary btn-block" href="#"><i class="fa fa-eye"></i> Launch</a>
        </div>
      </div>

    </div>

  </div>
  <div class="col-md-4">

    <div class="qt-portfolio-item">
      <a href="portfolio-single-item-1.php">
        <img class="img-responsive qt-fade" src="resources/img/portfolio/6.jpg" alt="">
      </a>
      <h3><a href="#">Project Six</a></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>

      <div class="row">
        <div class="col-md-6">
          <a class="btn btn-info btn-block" href="portfolio-single-item-1.php"><i class="fa fa-info-circle"></i> Details</a>
        </div>
        <div class="col-md-6">
          <a class="btn btn-primary btn-block" href="#"><i class="fa fa-eye"></i> Launch</a>
        </div>
      </div>

    </div>

  </div>
</div>
<!-- /.row -->



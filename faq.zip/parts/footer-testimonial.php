
<!-- =========================================================================================== -->
<!-- =========================== Footer Quote ================================================== -->
<!-- =========================================================================================== -->

<section class="qt-footer-testimonial-wrapper">
  <div class="container">
    <div class="row">

      <div class="col-md-12">
        <div class="qt-footer-testimonial">

          <h4><i class="fa fa-quote-left fa-3x"></i></h4>

          <h2>What our clients say</h2>

          <div class="qt-footer-testimonial-text">
            <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>

            <p class="qt-footer-testimonial-author">John Doe, The Company Inc.</p>

          </div>

        </div>
      </div>

    </div>
  </div>
</section>


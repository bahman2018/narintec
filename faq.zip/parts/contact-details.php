
<div class="qt-widget-box">

  <div class="qt-widget-header">
    <h3> <i class="fa fa-map-marker"></i> Find Us</h3>
  </div>

  <div class="qt-widget-body">

    <?php

    /*
    Note: using include_once instead on just include
    to make sure MAP is only included once. As two contact pages are including the same file.
    */

    ?>
    <?php include_once 'contact-map.php'; ?>

    <div class="well">

      <h3>CreaTec - HTML5 Website</h3>
      <h4>123 Good Street, London, UK</h4>

      <p><i class="fa fa-phone fa-fw"></i> 0203 6896 576 </p>
      <p><i class="fa fa-fax fa-fw"></i> 0203 6896 576 </p>
      <p><i class="fa fa-envelope-o fa-fw"></i> <a href="mailto:support@quickthemes.net">support@quickthemes.net</a> </p>
      <p><i class="fa fa-clock-o fa-fw"></i> Monday-Friday: 9:00 AM to 5:00 PM</p>

    </div>

  </div>
</div>

















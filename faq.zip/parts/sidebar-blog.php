
<?php include 'widget-search.php'; ?>
<?php include 'widget-categories.php'; ?>
<?php include 'widget-newsletter.php'; ?>
<?php include 'widget-well.php'; ?>

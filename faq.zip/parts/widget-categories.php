
<div class="qt-widget-box">

  <div class="qt-widget-header">
    <h3>Categories</h3>
  </div>

  <div class="qt-widget-body">

    <ul class="list-group">
      <li class="list-group-item"><a href="#" >Bootstrap</a> <span class="badge">6</span></li>
      <li class="list-group-item"><a href="#" >Marketing </a> <span class="badge">4</span></li>
      <li class="list-group-item"><a href="#" >Personal Development</a> <span class="badge">6</span></li>
      <li class="list-group-item"><a href="#" >Website Design</a> <span class="badge">6</span></li>
      <li class="list-group-item"><a href="#" >WordPress</a> <span class="badge">5</span></li>
    </ul>

  </div>

</div>
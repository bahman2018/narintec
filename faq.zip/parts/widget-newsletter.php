<div class="qt-widget-box">

  <div class="qt-widget-header">
    <h3>Email Newsletter</h3>
  </div>

  <div class="qt-widget-body">
    <p>If you join our mailing list we will send you a brief introduction to the way the book can be used to unlock your passion, achieve your goals and reach ultimate success. </p>

    <form>

    <div class="input-group">
      <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
      <input type="text" name="EMAIL" class="form-control" placeholder="Enter your email address" required>
      <span class="input-group-btn">
        <button type="submit" class="btn btn-primary">Subscribe</button>
      </span>
    </div><!-- /input-group -->

    </form>

  </div>
</div>
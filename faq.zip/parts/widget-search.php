
<div class="qt-widget-box">

  <div class="qt-widget-header">
    <h3>Search Blog</h3>
  </div>

  <div class="qt-widget-body">

    <form>

    <div class="input-group">
      <span class="input-group-addon"><i class="fa fa-search"></i></span>
      <input type="text" name="EMAIL" class="form-control" placeholder="Type here to search..." required>
      <span class="input-group-btn">
        <button type="submit" class="btn btn-primary">Search</button>
      </span>
    </div><!-- /input-group -->

    </form>

  </div>
</div>